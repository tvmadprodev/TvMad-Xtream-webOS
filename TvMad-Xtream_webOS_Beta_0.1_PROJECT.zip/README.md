TvMad-Xtream webOS Beta 0.1
Port oparty na ostatnim projekcie Android z 2026-09-15.
- interfejs startowy 3 kafle zgodny z Android TV
- Xtream LIVE/VOD/Series, M3U LIVE, Enigma2/OpenWebIF LIVE
- natywny HTML5 video player webOS, MiniTV/fullscreen, picony, EPG, side panels, MultiEPG
- WebInterface port 5557 przez dołączony JS Service; konfiguracja serwerów synchronizuje się z aplikacją
Build: ares-package app services/pl.tvmad.app.xtream.service
