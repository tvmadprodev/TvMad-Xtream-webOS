# TvMad-Xtream webOS Beta 0.1
Pełny pierwszy port funkcjonalny dla LG webOS24, oparty na aktualnym projekcie Android.
Zawiera oryginalne grafiki Android, XCODES/M3U/Enigma2, LIVE, VOD, Series, MiniTV,
fullscreen, EPG/MultiEPG, historię, boczne panele, Magic Remote i WebInfo 5557.
