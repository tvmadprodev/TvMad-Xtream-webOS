# TvMad-Xtream webOS Beta 0.1

Eksperymentalny port TvMad-Xtream dla LG webOS TV, przygotowany na bazie funkcji i wyglądu projektu Android.

## Beta 0.1
- FHD 1920x1080 UI, niezależne od rozdzielczości materiału wideo
- sterowanie pilotem 5-way i obsługa wskaźnika Magic Remote (hover/click)
- serwery XCODES zapisywane w localStorage
- LIVE: kategorie, kanały, MiniTV i fullscreen
- fullscreen: UP/DOWN zmiana kanału, LEFT panel kanałów, RIGHT ukrycie panelu
- przygotowane ekrany VOD/Series do dalszego portowania
- eksperymentalny WebInfo na porcie 5557 przez JS service
- osobny GitHub Actions workflow budujący IPK

## GitHub
Wgraj zawartość ZIP-a do osobnego repozytorium. Workflow `.github/workflows/build-webos.yml`
buduje paczkę IPK i publikuje ją jako Artifact.

## Ważne
WebInfo i odtwarzanie IPTV muszą zostać zweryfikowane na fizycznym LG webOS24. To pierwszy build testowy.
Nie zawiera ani nie modyfikuje projektu Android.
