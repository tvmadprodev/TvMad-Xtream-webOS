
const Service=require('webos-service');
const http=require('http');
const service=new Service('pl.tvmad.app.xtream.service');
let state={screen:'start',source:'',channel:'',sources:[]};

service.register('setState',msg=>{ state=Object.assign({},state,msg.payload.state||{}); msg.respond({returnValue:true}); });
service.register('getState',msg=>msg.respond({returnValue:true,state}));

const page=()=>`<!doctype html><meta charset="utf-8"><title>TvMad-Xtream WebInfo</title>
<style>body{font-family:Arial;background:#07111f;color:#fff;padding:35px}h1{color:#37b5ff}.box{background:#0d1d30;border:1px solid #294866;border-radius:14px;padding:22px;margin:18px 0}b{color:#f4b94a}</style>
<h1>TvMad-Xtream • WebInfo</h1><div class="box"><b>Status:</b> działa • port 5557</div>
<div class="box"><b>Ekran:</b> ${state.screen||'-'}<br><b>Serwer:</b> ${state.source||'-'}<br><b>Kanał:</b> ${state.channel||'-'}</div>
<div class="box"><b>Serwery w aplikacji:</b> ${(state.sources||[]).map(x=>x.name).join(', ')||'brak'}</div>`;
let server;
try{
 server=http.createServer((req,res)=>{
   if(req.url==='/api/status'){res.writeHead(200,{'Content-Type':'application/json','Access-Control-Allow-Origin':'*'});return res.end(JSON.stringify({ok:true,state}));}
   res.writeHead(200,{'Content-Type':'text/html; charset=utf-8'});res.end(page());
 });
 server.listen(5557,'0.0.0.0');
}catch(e){}
